class NodalData:

    def __init__(self, nodal_data):
        self.data = nodal_data
        return
